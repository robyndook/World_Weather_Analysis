# Add your API key
api_key = "fvAG7OyUfSzjkrWifbGgAIG374piUiJN"
NYT_API_KEY = "fvAG7OyUfSzjkrWifbGgAIG374piUiJN"
