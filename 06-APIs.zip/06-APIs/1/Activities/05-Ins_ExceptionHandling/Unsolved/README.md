### Making Exceptions

## Instructions:

* Without removing any of the lines from the starter code provided, create `try` and `except` blocks that will allow the application to run without terminating.
